package Primero;

import javax.swing.JOptionPane;
import programasprimero.*;
public class Menu {

 public static void main (String [ ]args){
     byte seleccion;
     String nombre;
     
     seleccion=Byte.parseByte(JOptionPane.showInputDialog("1-. Programa de despedida \n "
+ " 2-. Comparador de dos numeros  \n "
+ " 3-. Comparador de tres numeros \n "
+ " 4-. Calculadora de hipotenusa \n "
+ " 5-. Area y Volumen de un cilindro \n "
+ " 6-. Numero par o impar \n"
+ " 7-. Nota de calificación \n "
+ " 8-.  Descuentos en veterinaria \n "
+ " 9-. Designaciones en un hospital \n "
+ " 10-. Calculadora de promedios con for \n "
+ " 11-. Calculadora de IMC \n "
+ " 12-. Tablas de multiplicar \n "
+ " 13-. Calificaciones con arreglos \n "
+ " 14-. Reporte de ventas de sudaderas \n"
+ " Ingresa el numero de programa a ejecutar \n "));             
     
    
     switch(seleccion){
         case 1:
              nombre = JOptionPane.showInputDialog("Escribe tu nombre compreto ");
                /*creando un objeto que se llama "obj" para llamar a los metodo
                que estan en la clase llamada Despedida*/
                Despedida despedidaobj = new Despedida();
                despedidaobj.mensajeDespedida(nombre); //llamando al metodo de despedida
             break;
         case 2:
             Ejer_1 ejer_1obj = new Ejer_1();
             ejer_1obj.main(args);
             break;
         case 3: 
             Ejer_2 ejer_2obj = new Ejer_2();
             ejer_2obj.main(args);
             break;
         case 4:
             Ejer_4 ejer_4obj = new Ejer_4();
             ejer_4obj.main(args);
             break;
         case 5:
             Ejer_5 ejer_5obj = new Ejer_5();
             ejer_5obj.main(args);
             break;
         case 6:
             Ejer_6 ejer_6obj = new Ejer_6();
             ejer_6obj.main(args);
             break;
         case 7:
             Ejer_7 ejer_7obj = new Ejer_7();
             ejer_7obj.main(args);
             break;
         case 8:
             Ejer_8 ejer_8obj = new Ejer_8();
             ejer_8obj.main(args);
             break;
         case 9:
             Ejer_9 ejer_9obj = new Ejer_9();
             ejer_9obj.main(args);
             break;
         case 10:
             CicloFor cicloforobj = new CicloFor();
             cicloforobj.main(args);
             break;
         case 11:
             CicloIMC cicloimcobj = new CicloIMC();
             cicloimcobj.main(args);
             break;
         case 12:
             CicloTablasdeMultiplicar ciclotablasdemultiplicarobj = new CicloTablasdeMultiplicar();
             ciclotablasdemultiplicarobj.main(args);
             break;
         case 13:
              CalificacionesconArreglos calificacionesconarreglosobj = new CalificacionesconArreglos();
              calificacionesconarreglosobj.main(args);
             break;
         case 14:
             Arreglos_ejer2 arreglos_ejer2obj = new Arreglos_ejer2();
             arreglos_ejer2obj.main(args);
             break;            
         default: 
             JOptionPane.showMessageDialog(null, "Opcion invalida, intentenuevamente");

         
     }
}    
}


/*Segundo metodo SINTAXIS

modificadorAcceso tipoRetorno identificador (lista de parametros) {...}
*/