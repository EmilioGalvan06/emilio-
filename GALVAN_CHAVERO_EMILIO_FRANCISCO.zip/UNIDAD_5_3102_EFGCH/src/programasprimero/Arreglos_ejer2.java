package programasprimero;

import java.util.Scanner;

public class Arreglos_ejer2{
    public Arreglos_ejer2(){
        
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Definir las constantes de precios
        final double PRECIO_MAYOREO = 150.0;

        // Solicitar el número de distribuidores
        System.out.println("Ingrese el número de distribuidores:");
        int numDistribuidores = scanner.nextInt();

        // Declarar los arreglos para almacenar los datos
        String[] distribuidores = new String[numDistribuidores];
        int[] cantidades = new int[numDistribuidores];
        double[] totales = new double[numDistribuidores];

        // Solicitar los datos de cada distribuidor
        for (int i = 0; i < numDistribuidores; i++) {
            System.out.println("Ingrese el nombre del distribuidor " + (i + 1) + ":");
            distribuidores[i] = scanner.next();

            System.out.println("Ingrese la cantidad de lotes vendidos a " + distribuidores[i] + ":");
            cantidades[i] = scanner.nextInt();

            // Calcular el total por distribuidor
            totales[i] = cantidades[i] * PRECIO_MAYOREO;
        }

        // Generar el reporte de ventas
        System.out.println("\n*** Reporte de Ventas Mensual ***");
        System.out.println("Mes:");
        System.out.println("No. | Distribuidor | Costo  | Cantidad | Total");
        for (int i = 0; i < numDistribuidores; i++) {
            System.out.printf("%d   | %s          | %.2f   | %d       | %.2f%n", (i + 1), distribuidores[i], PRECIO_MAYOREO, cantidades[i], totales[i]);
        }

        // Calcular el total de ventas
        double totalVentasMayoreo = 0.0;
        for (int i = 0; i < numDistribuidores; i++) {
            totalVentasMayoreo += totales[i];
        }

        // Imprimir el total de ventas al mayoreo
        System.out.println("-------------------------------");
        System.out.println("Total de Ventas al Mayoreo: $" + totalVentasMayoreo);

        // Opcionalmente, calcular y mostrar el precio de venta al menudeo
        double precioMenudeo = PRECIO_MAYOREO * (1 + 0.60);
        System.out.println("Precio de Venta al Menudeo: $" + precioMenudeo);
    }
}

    
