package programasprimero;


public class Despedida {
    public Despedida() {
    }
    
    public void mensajeDespedida(String nombre){
        System.out.println(nombre + " Estamos por terminar " + " el semestre, ya eres programador junior");
    }
}



