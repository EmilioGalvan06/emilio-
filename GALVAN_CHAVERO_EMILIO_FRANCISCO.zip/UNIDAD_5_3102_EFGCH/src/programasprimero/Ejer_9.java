package programasprimero;

public class Ejer_9 {
    public Ejer_9(){
        
    }
    public static void main (String[]args){
       int a,b,c,d,e, f;
        
    System.out.println("Consulta de designaciónes a hospital general"); 
    
    a=2000000*20/100;
    System.out.println("La designación al área de pediatria fue de: %20 = " +"$"+a);
    b=2000000*15/100;
    System.out.println("La designación al área de analisis clinicos fue de: %15 = " +"$"+b);
    c=2000000*40/100;
    System.out.println("La designación al área ginecologia fue de: %40 = " +"$"+c);
    d=2000000*10/100;
    System.out.println("La designación al área de infraestructura en sanitarios fue de: %10 = " +"$"+d);
    e=15;
    f= (int) (2000000*15/100);
    System.out.println("La desiganación al área de servicios generales fue de: "+"%"+e+"= "+"$"+f);
    {
        {
            {
                {
                    {
                        
                    }
                }
            }
        }
    }
    }
}

        
    
    
        
    


    
    

        
       
        

        
   
